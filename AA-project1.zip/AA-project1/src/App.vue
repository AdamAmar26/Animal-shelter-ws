<script>
import { RouterLink, RouterView } from 'vue-router';

export default {
  components: {
    RouterLink,
    RouterView
  }
}
</script>

<template>
      <nav class= "navbar">
        <RouterLink to="/" class="nav-item">Home</RouterLink>
        <RouterLink to="/adoptionInfo" class="nav-item">Adoption Information</RouterLink>
        <RouterLink to="/pets" class="nav-item">Listed Pets</RouterLink>
      </nav>
      <RouterView />
</template>

<style scoped>
header {
  line-height: 1.5;
  max-height: 100vh;
}

.navbar {
  background-color: #96c2ee; 
  padding: 15px;
  display: flex;
  justify-content: center; 
  align-items: center;
  position: sticky;
  top: 0;
  width: 100%;
  z-index: 1000;
}

nav a.router-link-exact-active {
  color: black;
}

nav a.router-link-exact-active:hover {
  background-color: transparent;
}

nav a {
  display: inline-block;
  padding: 0 1rem;
  border-left: 1px solid var(--color-border);
}

.nav-item {
  text-decoration: none;
  color: #0025f8;
  border-right: 1px solid black;
}

.navbar :hover{
  text-decoration: underline;
}

.nav-item:last-child {
  border-right: none;
}

</style>
