import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import AdoptionInfoView from '../views/AdoptionInfoView.vue'
import PetsView from '../views/PetsView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/adoptionInfo',
      name: 'Adoption Information',
      component: AdoptionInfoView
    },
    {
      path: '/pets',
      name: 'Pets',
      component: PetsView
    }
  ]
})

export default router
