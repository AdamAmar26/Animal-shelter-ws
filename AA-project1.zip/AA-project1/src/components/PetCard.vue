<template>
    <div class="pet-card">
      <h2>{{ pet.name }}</h2>
      <img :src="pet.image" :alt="pet.name">
      <p>Age: {{ pet.age }}</p>
      <p>{{ pet.description }}</p>
      <p>Needs: {{ pet.needs }}</p>
      <p>Personality: {{ pet.personality }}</p>
      <p>Looking for a home in: {{ pet.refuge }}</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'PetCard',
    props: {
      pet: Object
    }
  }
  </script>
  
  <style>
  .pet-card {
    border: 1px solid #ccc;
    padding: 20px;
    margin-bottom: 20px;
  }
  .pet-card img {
    max-width: 200px;
  }
  </style>
  