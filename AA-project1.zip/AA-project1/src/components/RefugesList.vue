<template>
    <div v-if="showList" class="refuges-list">
      <h2>Available Refuges</h2>
      <ul>
        <li v-for="refuge in refuges" :key="refuge.id">{{ refuge.name }} - {{ refuge.location }} - Dogs Available: {{ refuge.dogsAvailable }}</li>
      </ul>
    </div>
  </template>
  
  <script>
  export default {
    name: 'RefugesList',
    props: {
      showList: Boolean
    },
    data() {
      return {
        refuges: [
          { id: 1, name: 'Happy Tails Shelter', location: 'New York, NY', dogsAvailable: 'Buddy, Charlie and Lucy'},
          { id: 2, name: 'Paws Haven', location: 'Los Angeles, CA', dogsAvailable: 'Bella, Daisy and Luna' },
          { id: 3, name: 'Forever Friends Rescue', location: 'Austin, TX', dogsAvailable: 'Max, Rocky, Molly and Bailey' }
        ]
      }
    }
  }
  </script>
  
  <style>
  .refuges-list {
    margin-top: 20px;
    padding: 10px;
    border: 1px solid #010101;
    background: linear-gradient(to left, #d8bfd8, #ffcccb); /* Light purple to light pink */
}
  </style>
  