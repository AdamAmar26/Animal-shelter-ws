<template>
<div class="home-page">
  <h1>Welcome to the Pet Adoption Center!</h1>
  <p>
    Our mission is to connect loving animals with kind-hearted people. Here, you'll find dogs of all breeds, ages, and personalities waiting for a forever home. Whether you're looking for a playful puppy or a calm companion, we’re here to help you find the perfect match!
  </p>
  <p>
    Explore our available pets, learn about the adoption process, and take the first step in making a difference in a pet’s life. By adopting a pet, you’re not only gaining a loyal friend, but you're also saving a life.
  </p>

  <img class="home-image" src="/src/assets/dogHome.jfif" alt="Happy dog ready for adoption">

  <p>
    Ready to get started? Head over to our <router-link to="/pets">Pets</router-link> page to browse all of our lovable companions waiting for a home. If you want to learn about the requirements for adoption, head to our <RouterLink to=/adoptionInfo>Adoption Information</RouterLink>page. Thank you for choosing to adopt!
  </p>
  <h2>Upcoming Adoption Events</h2>
    <p>Join us at our next event and meet your future furry friend in person!</p>
    <ul>
    <li>October 15th - Fall Pet Adoption Fair</li>
    <li>November 10th - Community Adoption Drive</li>
    <li>December 5th - Holiday Adoption Weekend</li>
    </ul>
</div>
</template>

<script>
export default {
name: 'Home'
}
</script>
