<template>
    <div class= "adoption-info-page">
      <h1>Adoption Process Information</h1>
      <p>Learn more about how to adopt a pet and what is required.</p>
      <button @click="toggleRefugesList">See Available Refuges</button>
      <RefugesList :showList="showRefuges"/>
      <h2>Common Dog Adoption Requirements</h2>
    <ul class="adoption-requirements">
      <li>Be at least 21 years old or the minimum age required by your local shelter.</li>
      <li>Provide valid identification, such as a driver's license or ID card.</li>
      <li>Complete an adoption application form with accurate and honest details.</li>
      <li>Consent to a home visit or virtual home inspection to ensure the environment is suitable for a dog.</li>
      <li>Show proof of residence (e.g., lease or mortgage) to confirm pets are allowed in your home.</li>
      <li>Ensure that all members of your household are on board with the adoption.</li>
      <li>Provide references from a veterinarian (if you’ve previously owned pets).</li>
      <li>Have a secure, fenced yard (required by many shelters, especially for larger breeds).</li>
      <li>Be financially capable of providing food, healthcare, and other needs for the dog.</li>
      <li>Sign an adoption contract agreeing to the shelter’s rules (e.g., no rehoming without shelter consent).</li>
      <li>Pay the adoption fee, which covers vaccinations, spaying/neutering, and microchipping.</li>
      <li>Be ready for a trial period or an adjustment phase where the shelter may check in on the dog’s well-being.</li>
    </ul>
    </div>

  </template>
  
  <script>
  import RefugesList from '@/components/RefugesList.vue';
  
  export default {
    name: 'AdoptionInfo',
    components: { RefugesList },
    data() {
      return {
        showRefuges: false
      }
    },
    methods: {
      toggleRefugesList() {
        this.showRefuges = !this.showRefuges;
      }
    }
  }
  </script>
  
  <style>
  button {
    margin-top: 20px;
    padding: 10px 15px;
    background-color: #96c2ee;
    color: black;
    border: none;
    cursor: pointer;
  }
  
  button:hover {
    background-color: #1f8bff;
  }
  </style>
  