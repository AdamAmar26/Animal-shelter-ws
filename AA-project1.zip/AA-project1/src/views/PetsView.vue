<template>
    <div class="pets-page">
      <h1>Available Pets for Adoption</h1>
      <div class="pets-list">
        <PetCard v-for="pet in pets" :key="pet.id" :pet="pet"/>
      </div>
    </div>
  </template>  
  
  <script>
  import PetCard from '@/components/PetCard.vue';
  
  export default {
    name: 'Pets',
    components: { PetCard },
    data() {
        return {
      pets: [
        {
          id: 1,
          name: 'Buddy',
          age: 3,
          description: 'Friendly and playful Labrador Retriever.',
          needs: 'A large space to run and daily exercise.',
          personality: 'Loyal, playful, and great with kids.',
          image: './src/assets/dog1.jpeg',
          refuge: 'Happy Tails Shelter' 
        },
        {
          id: 2,
          name: 'Max',
          age: 2,
          description: 'Gentle Golden Retriever with a heart of gold.',
          needs: 'A quiet home with lots of attention.',
          personality: 'Affectionate, calm, and easygoing.',
          image: './src/assets/dog2.jpeg',
          refuge: 'Forever Friends Rescue'
        },
        {
          id: 3,
          name: 'Bella',
          age: 1,
          description: 'Energetic Beagle who loves exploring.',
          needs: 'Lots of outdoor activities and companionship.',
          personality: 'Curious, active, and friendly.',
          image: './src/assets/dog3.jpg',
          refuge: 'Paws Haven'
        },
        {
          id: 4,
          name: 'Charlie',
          age: 4,
          description: 'Cuddly Bulldog who enjoys lounging around.',
          needs: 'A relaxed environment with plenty of naps.',
          personality: 'Chill, low-energy, and affectionate.',
          image: './src/assets/dog4.jfif',
          refuge: 'Happy Tails Shelter'
        },
        {
          id: 5,
          name: 'Lucy',
          age: 3,
          description: 'Smart and quick Border Collie who loves agility.',
          needs: 'Daily mental stimulation and exercise.',
          personality: 'Intelligent, energetic, and hardworking.',
          image: './src/assets/dog5.jfif',
          refuge: 'Happy Tails Shelter'
        },
        {
          id: 6,
          name: 'Rocky',
          age: 2,
          description: 'Strong German Shepherd with protective instincts.',
          needs: 'An experienced owner and plenty of exercise.',
          personality: 'Loyal, brave, and intelligent.',
          image: './src/assets/dog6.jfif',
          refuge: 'Forever Friends Rescue'
        },
        {
          id: 7,
          name: 'Molly',
          age: 1,
          description: 'Small but mighty Dachshund with a big personality.',
          needs: 'A cozy home with lots of love.',
          personality: 'Confident, curious, and lively.',
          image: './src/assets/dog7.jfif',
          refuge: 'Forever Friends Rescue'
        },
        {
          id: 8,
          name: 'Daisy',
          age: 5,
          description: 'Friendly and outgoing Boxer who loves playing.',
          needs: 'A family that enjoys outdoor activities.',
          personality: 'Energetic, friendly, and loyal.',
          image: './src/assets/dog8.jfif',
          refuge: 'Paws Haven'
        },
        {
          id: 9,
          name: 'Bailey',
          age: 2,
          description: 'Adventurous Australian Shepherd.',
          needs: 'A large yard and lots of physical activity.',
          personality: 'Energetic, intelligent, and playful.',
          image: './src/assets/dog9.jfif',
          refuge: 'Forever Friends Rescue'
        },
        {
          id: 10,
          name: 'Luna',
          age: 3,
          description: 'Siberian Husky with striking blue eyes.',
          needs: 'Cold weather and plenty of exercise.',
          personality: 'Independent, energetic, and vocal.',
          image: './src/assets/dog10.jfif',
          refuge: 'Paws Haven'
        }
      ]
    }
  }
}
</script>
  